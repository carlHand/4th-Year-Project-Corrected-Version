package com.projectyr4x00091174.carl.traingain;

/**
 * Created by carl on 04/11/2014.
 */
public class Item {
        public String Id;
        public String Text;
}
